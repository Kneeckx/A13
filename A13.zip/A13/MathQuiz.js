var firstVal = 0;
var secondVal = 0;

var min = -50;
var max = 50;
const operators = ['+', '-', 'x', '/'];
var operator = "";
var diffLevel = "";
var answer = 0;
var score = 0;
var questions = 0;

const restartButton = document.getElementById('restart-button');
const beginner = document.getElementById('beginner');
const intermediate = document.getElementById('intermediate');
const advanced = document.getElementById('advanced');
const restart = document.getElementById('restart');
restart.style.display = 'none';

beginner.addEventListener('click', () => {
    diffLevel = "beginner";
    min = -50;
    max = 50;
});

intermediate.addEventListener('click',  () => {
    diffLevel = "intermediate";
    min = -1000;
    max = 1000;
});
advanced.addEventListener('click',  () => {
    diffLevel = "advanced";
    min = -10000;
    max = 10000;
});


function randomizer(diff) {
    operator = operators[Math.floor(Math.random() * operators.length)];
    console.log(operator)
    
    firstVal = Math.floor(Math.random() * (max-min) + min);
    secondVal = Math.floor(Math.random() * (max-min) + min);

}

function MathQuiz() {
    questions++;
    document.getElementById('score').innerHTML = 'Questions correct:' + score + " / 10";
    randomizer(diffLevel);
    var container = document.getElementById('container');
    container.innerHTML = '<h2>' + firstVal + ' ' + operator + ' ' + secondVal + '</h2>'
    + '<div id="equation"><h2>=</h2> <input type="number" id="userAnswer" placeholder="Enter your answer"></div>' ;
    document.getElementById('message').style.display = 'none';
    console.log(firstVal + " " + operator + " " + secondVal);
    console.log(diffLevel);
    console.log(min + " " + max);
    console.log(questions + " " + score);   
}




function checkAnswer() {
    if(operator == '+'){
        answer = firstVal + secondVal;
    }
    if(operator == '-'){
    answer = firstVal - secondVal;
    }
    if(operator == '/'){
    answer = firstVal / secondVal;
    }
    if(operator == 'x'){
    answer = firstVal * secondVal;
    }
    var userAnswer = document.getElementById('userAnswer').value;
    if(userAnswer == answer){
        document.getElementById('feedback').innerHTML = 'Correct!';
        score++;
    }
    else{
        document.getElementById('feedback').innerHTML = 'Incorrect!';
    }
    
}
    

MathQuiz();

function next(){
    if(questions < 10) {
        document.getElementById('feedback').innerHTML = "";
        document.getElementById('container').style.display = 'grid';
        document.getElementById('next').style.display = 'grid';
        MathQuiz();
        restart.style.display = 'none';
    }
    if(questions >= 10){
        document.getElementById('message').style.display = 'block';
        document.getElementById('container').style.display = 'none';
        document.getElementById('feedback').innerHTML = 'Questions correct:' + score + " / 10";
        document.getElementById('restart').style.display = 'inline-block';
        document.getElementById('options').style.display = 'none';
        document.getElementById('next').style.display = 'none';
    }
}


restartButton.addEventListener('click', ()=>{
    score = 0;
    questions = 0;
    document.getElementById('score').innerHTML = 'Questions correct:' + score + " / 10";
    document.getElementById('feedback').innerHTML = "";
    document.getElementById('restart').style.display = 'none';
    document.getElementById('options').style.display = 'grid';
    document.getElementById('next').style.display = 'grid';
    document.getElementById('container').style.display = 'grid';
    MathQuiz();
    console.log('You have restarted the game');
});